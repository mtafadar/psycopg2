import psycopg2

def lambda_handler(event, context):
    # Your function logic here
    return {
        'statusCode': 200,
        'body': 'Hello from Lambda!'
    }
